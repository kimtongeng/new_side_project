<?php

return [
    'name' => 'StockCount',
];
