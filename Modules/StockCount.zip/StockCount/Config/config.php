<?php

return [
    'name' => 'StockCount',
];
